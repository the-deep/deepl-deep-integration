from typing import Tuple, List, Any

WordStruct = Tuple[float, float, float, float, str, int, int, int]
WordPos = Tuple[int, WordStruct]
MergedWordPos = List[Any]

DOCUMENT_LENGTH_THRESHOLD: int = 50
NULL: float = 0.0
LINE_THRESHOLD: float = 0.8
LINE_THRESHOLD_LOW: float = 0.1
LINE_MEDIAN_THRESHOLD: float = 2
LINE_MEDIAN_THRESHOLD_LOW: float = 1
VERTICAL_THRES_TOT: float = 10.0
VERTICAL_THRES_SEC: float = 5.0
VERTICAL_THRES_CORR: float = 0.8
FONTSIZE_MIN: float = 1.1
FONTSIZE_DIFFERENCE: float = 0.35
RESCALE_MIN_DIFFERENCE: float = 0.0001
HOR_THRES_TOT: float = 1.0
HOR_THRES_SEC: float = 0.5
HOR_CORRECTION: float = 0.3
MIN_WORDS_IN_COLUMN: int = 5
ITERATION_NUM: int = 3
MAX_WHILE: int = 100

