from .parser.base import TextFromFile
from .parser.dom import TextFromWeb
